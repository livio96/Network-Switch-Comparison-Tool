/**
 * 
 Livio Beqiri
 Joseph Felano 

 Telquest International 

 April 3rd, 2019 

 */
(function() {

	var viewEl = document.querySelector('.view'),
		gridEl = viewEl.querySelector('.grid'),
		items = [].slice.call(gridEl.querySelectorAll('.product')),
		basket;

	// the compare basket
	function CompareBasket() {
		this.el = document.querySelector('.compare-basket');
		this.compareCtrl = this.el.querySelector('.action--compare');
		this.compareWrapper = document.querySelector('.compare'),
		this.closeCompareCtrl = this.compareWrapper.querySelector('.action--close')
		
        
        
		this.itemsAllowed = 5;
		this.totalItems = 0;
		this.items = [];

		this.compareCtrl.addEventListener('click', this._compareItems.bind(this));
		var self = this;
		this.closeCompareCtrl.addEventListener('click', function() {
			classie.add(self.el, 'compare-basket--active');
			classie.remove(viewEl, 'view--compare');
		});
	}
    
        
     
	CompareBasket.prototype.add = function(item) {
		if( this.isFull() ) {
			return true;
		}

		classie.add(item, 'product--selected');

		var preview = this._createItemPreview(item);
		this.el.insertBefore(preview, this.el.childNodes[0]);
		this.items.push(preview);

		this.totalItems++;
		if( this.isFull() ) {
			classie.add(this.el, 'compare-basket--full');
		}

		classie.add(this.el, 'compare-basket--active');
	};

	   CompareBasket.prototype._createItemPreview = function(item) {
		var self = this;

		var preview = document.createElement('div');
		preview.className = 'product-icon';
		preview.setAttribute('data-idx', items.indexOf(item));
		
		var removeCtrl = document.createElement('button');
		removeCtrl.className = 'action action--remove';
		removeCtrl.innerHTML = '<i class="fa fa-remove"></i><span class="action__text action__text--invisible">Remove product</span>';
		removeCtrl.addEventListener('click', function() {
			self.remove(item);
		});
		
		var productImageEl = item.querySelector('img.product__image').cloneNode(true);

		preview.appendChild(productImageEl);
		preview.appendChild(removeCtrl);

		var productInfo = item.querySelector('.product__info').innerHTML;
		preview.setAttribute('data-info', productInfo);

		return preview;
	};

	CompareBasket.prototype.remove = function(item) {
		classie.remove(this.el, 'compare-basket--full');
		classie.remove(item, 'product--selected');
		var preview = this.el.querySelector('[data-idx = "' + items.indexOf(item) + '"]');
		this.el.removeChild(preview);
		this.totalItems--;

		var indexRemove = this.items.indexOf(preview);
		this.items.splice(indexRemove, 1);

		if( this.totalItems === 0 ) {
			classie.remove(this.el, 'compare-basket--active');
		}

		
		var checkbox = item.querySelector('.action--compare-add > input[type = "checkbox"]');
		if( checkbox.checked ) {
			checkbox.checked = false;
		}
	};

    
	CompareBasket.prototype._compareItems = function() {
		var self = this;

		// remove all previous items inside the compareWrapper element
		[].slice.call(this.compareWrapper.querySelectorAll('div.compare__item')).forEach(function(item) {
			self.compareWrapper.removeChild(item);
		});
        
        

		for(var i = 0; i < this.totalItems; i++) {
			var compareItemWrapper = document.createElement('div');
			compareItemWrapper.className = 'compare__item';

			var compareItemEffectEl = document.createElement('div');
			compareItemEffectEl.className = 'compare__effect';

			compareItemEffectEl.innerHTML = this.items[i].getAttribute('data-info');
			compareItemWrapper.appendChild(compareItemEffectEl);

			this.compareWrapper.insertBefore(compareItemWrapper, this.compareWrapper.childNodes[0]);

		}

		setTimeout(function() {
			classie.remove(self.el, 'compare-basket--active');
			classie.add(viewEl, 'view--compare');
		}, 25);
	};

	CompareBasket.prototype.isFull = function() {
		return this.totalItems === this.itemsAllowed;
	};

	function init() {
		basket = new CompareBasket();
		initEvents();
	}

	function initEvents() {
		items.forEach(function(item) {
			var checkbox = item.querySelector('.action--compare-add > input[type = "checkbox"]');
			checkbox.checked = false;

			// ctrl to add to the "compare basket"
			checkbox.addEventListener('click', function(ev) {
				if( ev.target.checked ) {
					if( basket.isFull() ) {
						ev.preventDefault();
						return false;
					}
					basket.add(item);
				}
				else {
					basket.remove(item);
				}
			});
		});
	}

	init();

})();



'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Shuffle = window.Shuffle;

var Demo = function () {
  function Demo(element) {
    _classCallCheck(this, Demo);

    this.element = element;
    this.shuffle = new Shuffle(element, {
      itemSelector: '.product',
      sizer: element.querySelector('.my-sizer-element')
    });

    // Log events.
    this.addShuffleEventListeners();
    this._activeFilters = [];
    this.addFilterButtons();
    //this.addSorting();
    this.addSearchFilter();
  }

  
 


  _createClass(Demo, [{
    key: 'addShuffleEventListeners',
    value: function addShuffleEventListeners() {
      this.shuffle.on(Shuffle.EventType.LAYOUT, function (data) {
        console.log('layout. data:', data);
      });
      this.shuffle.on(Shuffle.EventType.REMOVED, function (data) {
        console.log('removed. data:', data);
      });
    }
  }, {
    key: 'addFilterButtons',
    value: function addFilterButtons() {
      var options = document.querySelector('.filter-options');
      if (!options) {
        return;
      }

      var filterButtons = Array.from(options.children);
      var onClick = this._handleFilterClick.bind(this);
      filterButtons.forEach(function (button) {
        button.addEventListener('click', onClick, false);
      });
    }
  }, {
    key: '_handleFilterClick',
    value: function _handleFilterClick(evt) {
      var btn = evt.currentTarget;
      var isActive = btn.classList.contains('active');
	  var btnGroup = btn.getAttribute('data-group');

      this._removeActiveClassFromChildren(btn.parentNode);

      var filterGroup = void 0;
      if (isActive) {
        btn.classList.remove('active');
        filterGroup = Shuffle.ALL_ITEMS;
      } else {
        btn.classList.add('active');
        filterGroup = btnGroup;
      }

      this.shuffle.filter(filterGroup);
    }
  }, {
    key: '_removeActiveClassFromChildren',
    value: function _removeActiveClassFromChildren(parent) {
      var children = parent.children;

      for (var i = children.length - 1; i >= 0; i--) {
        children[i].classList.remove('active');
      }
    }
  }, {
    key: 'addSorting',
    value: function addSorting() {
      var buttonGroup = document.querySelector('.sort-options');
      if (!buttonGroup) {
        return;
      }
      buttonGroup.addEventListener('change', this._handleSortChange.bind(this));
    }
  }, {
    key: '_handleSortChange',
    value: function _handleSortChange(evt) {
      // Add and remove `active` class from buttons.
      var buttons = Array.from(evt.currentTarget.children);
      buttons.forEach(function (button) {
        if (button.querySelector('input').value === evt.target.value) {
          button.classList.add('active');
        } else {
          button.classList.remove('active');
        }
      });

      // Create the sort options to give to Shuffle.
      var value = evt.target.value;

      var options = {};

      function sortByDate(element) {
        return element.getAttribute('data-created');
      }

      function sortByTitle(element) {
        return element.getAttribute('data-title').toLowerCase();
      }

      if (value === 'date-created') {
        options = {
          reverse: true,
          by: sortByDate
        };
      } else if (value === 'title') {
        options = {
          by: sortByTitle
        };
      }
      this.shuffle.sort(options);
    }

    // Advanced filtering

  }, {
    key: 'addSearchFilter',
    value: function addSearchFilter() {
      var searchInput = document.querySelector('.js-shuffle-search');
      if (!searchInput) {
        return;
      }
      searchInput.addEventListener('keyup', this._handleSearchKeyup.bind(this));
    }

    /**
     * Filter the shuffle instance by items with a title that matches the search input.
     * @param {Event} evt Event object.
     */

  }, {
    key: '_handleSearchKeyup',
    value: function _handleSearchKeyup(evt) {
      var searchText = evt.target.value.toLowerCase();
      this.shuffle.filter(function (element, shuffle) {
        // If there is a current filter applied, ignore elements that don't match it.
        if (shuffle.group !== Shuffle.ALL_ITEMS) {
          // Get the item's groups.
          var groups = JSON.parse(element.getAttribute('data-groups'));
          var isElementInCurrentGroup = groups.indexOf(shuffle.group) !== -1;
          // Only search elements in the current group
          if (!isElementInCurrentGroup) {
            return false;
          }
        }
        var titleElement = element.querySelector('.product__title');
        var titleText = titleElement.textContent.toLowerCase().trim();
        var descriptionElement = element.querySelector('.product__title+p');
        var descriptionText = descriptionElement.textContent.toLowerCase().trim();
        return titleText.indexOf(searchText) !== -1 || descriptionText.indexOf(searchText) !== -1;
      });
    }
  }]);

  return Demo;
}();

document.addEventListener('DOMContentLoaded', function () {
  window.demo = new Demo(document.getElementById('grid'));
});